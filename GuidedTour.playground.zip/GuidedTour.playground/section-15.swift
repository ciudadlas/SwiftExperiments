let emptyArray = [String]()
let emptyDictionary = [String: Float]()
